# SH4RK SU — Android Studio starter project

A clean AMOLED/cyan root-management front-end built with Kotlin and Jetpack Compose.

## Included in this starter
- Dashboard with root status, backend label, Android/kernel/device and SELinux information.
- Read-only detection for generic `su`, `ksud`, Magisk and APatch command availability.
- Read-only module directory listing from `/data/adb/modules`.
- Dark UI with Dashboard / Modules / Tools navigation.

## Important limitations
This is a **source project**, not a prebuilt APK. It is a safe starter implementation, not a complete SukiSU replacement.
It does not bundle `ksud`, root binaries, or third-party modules. It cannot install every module universally:
modules and root backends are device-, kernel-, Android-, and manager-version-dependent.
Module install/disable/remove, WebUI, boot-image flashing, backup/restore and privileged daemon integration
must be implemented and tested against the exact backend APIs before being enabled.

The app requests no Android permissions in this starter. Root commands run only if a compatible `su`
binary is present and the user grants the prompt. Do not grant root to unknown builds.

## Build an APK
1. Install Android Studio (current stable) and Android SDK Platform 35.
2. Extract this folder.
3. Open the folder in Android Studio.
4. Let Gradle sync finish.
5. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. The debug APK is normally at `app/build/outputs/apk/debug/app-debug.apk`.

## Package
`com.sh4rk.su`

## Next engineering milestones
1. Add backend-specific adapters using documented KernelSU / KernelSU Next / Magisk / APatch interfaces.
2. Add a signed, audited module installer with archive path validation and rollback.
3. Add module state toggles with backend-aware semantics.
4. Add ksud capability/version detection and WebUI integration where supported.
5. Add tests on a disposable test device before enabling write operations.
