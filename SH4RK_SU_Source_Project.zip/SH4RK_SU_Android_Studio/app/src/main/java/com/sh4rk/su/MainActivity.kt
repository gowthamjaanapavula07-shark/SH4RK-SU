package com.sh4rk.su

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.launch

private val Bg = Color(0xFF080D12)
private val Panel = Color(0xFF111B24)
private val Cyan = Color(0xFF00D5E8)
private val Muted = Color(0xFF8CA0AE)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { SharkApp() }
    }
}

data class RootInfo(
    val granted: Boolean = false,
    val backend: String = "Not detected",
    val kernel: String = "—",
    val android: String = android.os.Build.VERSION.RELEASE ?: "—",
    val device: String = "${android.os.Build.MANUFACTURER} ${android.os.Build.MODEL}",
    val selinux: String = "Unknown",
    val detail: String = "Tap refresh to inspect root status."
)

@Composable
fun SharkApp() {
    var tab by remember { mutableStateOf("Dashboard") }
    var info by remember { mutableStateOf(RootInfo()) }
    var modules by remember { mutableStateOf<List<String>>(emptyList()) }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("Ready") }

    suspend fun refresh() {
        busy = true
        val result = withContext(Dispatchers.IO) { RootShell.inspect() }
        info = result.first
        modules = result.second
        message = result.first.detail
        busy = false
    }

    LaunchedEffect(Unit) { refresh() }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Cyan, background = Bg, surface = Panel,
            onBackground = Color.White, onSurface = Color.White
        )
    ) {
        Scaffold(
            containerColor = Bg,
            bottomBar = {
                NavigationBar(containerColor = Panel) {
                    listOf("Dashboard", "Modules", "Tools").forEach { item ->
                        NavigationBarItem(
                            selected = tab == item,
                            onClick = { tab = item },
                            icon = {
                                Icon(
                                    when (item) {
                                        "Dashboard" -> Icons.Default.Dashboard
                                        "Modules" -> Icons.Default.Extension
                                        else -> Icons.Default.Build
                                    }, contentDescription = item
                                )
                            },
                            label = { Text(item) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Cyan,
                                selectedTextColor = Cyan,
                                indicatorColor = Color(0xFF18343B),
                                unselectedIconColor = Muted,
                                unselectedTextColor = Muted
                            )
                        )
                    }
                }
            }
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(18.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(42.dp).background(Cyan, RoundedCornerShape(14.dp)),
                        contentAlignment = Alignment.Center) {
                        Text("S", color = Bg, fontWeight = FontWeight.Black, fontSize = 25.sp)
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text("SH4RK SU", fontSize = 22.sp, fontWeight = FontWeight.Black, color = Color.White)
                        Text("ROOT CONTROL CENTER", fontSize = 10.sp, color = Cyan, letterSpacing = 2.sp)
                    }
                    IconButton(onClick = { /* refresh is triggered by dashboard button */ }) {
                        Icon(Icons.Default.Security, contentDescription = "Security", tint = Cyan)
                    }
                }
                Spacer(Modifier.height(22.dp))
                when (tab) {
                    "Dashboard" -> Dashboard(info, busy, message, onRefresh = {
                        // Refresh on a coroutine scope
                    }, onRefreshAsync = { refresh() })
                    "Modules" -> ModulesScreen(modules, info.granted, onRefresh = { refresh() })
                    else -> ToolsScreen(info)
                }
            }
        }
    }
}

@Composable
fun Dashboard(
    info: RootInfo, busy: Boolean, message: String,
    onRefresh: () -> Unit, onRefreshAsync: suspend () -> Unit
) {
    val scope = rememberCoroutineScope()
    Text("System overview", color = Muted, fontSize = 13.sp)
    Spacer(Modifier.height(10.dp))
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(22.dp)) {
        Column(Modifier.fillMaxWidth().padding(18.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Shield, tint = if (info.granted) Cyan else Color(0xFFFFB454),
                    modifier = Modifier.size(30.dp), contentDescription = null)
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text(if (info.granted) "ROOT ACCESS AVAILABLE" else "ROOT NOT CONFIRMED",
                        fontWeight = FontWeight.Bold, color = Color.White)
                    Text(info.backend, color = Muted, fontSize = 12.sp)
                }
                Surface(color = if (info.granted) Color(0xFF123C3B) else Color(0xFF49321B),
                    shape = RoundedCornerShape(50)) {
                    Text(if (info.granted) "ACTIVE" else "CHECK",
                        modifier = Modifier.padding(horizontal = 11.dp, vertical = 6.dp),
                        color = if (info.granted) Cyan else Color(0xFFFFC078), fontSize = 10.sp)
                }
            }
            Spacer(Modifier.height(16.dp))
            Button(onClick = { scope.launch { onRefreshAsync() } },
                enabled = !busy, colors = ButtonDefaults.buttonColors(containerColor = Cyan),
                modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Default.Refresh, contentDescription = null, tint = Bg)
                Spacer(Modifier.width(8.dp))
                Text(if (busy) "Checking…" else "Refresh root status", color = Bg, fontWeight = FontWeight.Bold)
            }
            Text(message, color = Muted, fontSize = 11.sp, modifier = Modifier.padding(top = 8.dp))
        }
    }
    Spacer(Modifier.height(18.dp))
    Text("Device information", color = Muted, fontSize = 13.sp)
    Spacer(Modifier.height(10.dp))
    InfoRow("Device", info.device)
    InfoRow("Android", info.android)
    InfoRow("Kernel", info.kernel)
    InfoRow("SELinux", info.selinux)
    Spacer(Modifier.height(14.dp))
    Text("Supported integrations", color = Muted, fontSize = 13.sp)
    Spacer(Modifier.height(8.dp))
    Text("KernelSU • KernelSU Next • Magisk • APatch",
        color = Cyan, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
    Text("Backend availability depends on your device and installed root solution.",
        color = Muted, fontSize = 11.sp)
}

@Composable
fun InfoRow(label: String, value: String) {
    Card(Modifier.fillMaxWidth().padding(vertical = 4.dp),
        colors = CardDefaults.cardColors(containerColor = Panel),
        shape = RoundedCornerShape(13.dp)) {
        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(label, color = Muted, modifier = Modifier.weight(1f), fontSize = 12.sp)
            Text(value, color = Color.White, fontWeight = FontWeight.Medium, fontSize = 12.sp)
        }
    }
}

@Composable
fun ModulesScreen(modules: List<String>, root: Boolean, onRefresh: () -> Unit) {
    Text("Module manager", fontSize = 21.sp, fontWeight = FontWeight.Bold)
    Text("Detected modules in /data/adb/modules", color = Muted, fontSize = 12.sp)
    Spacer(Modifier.height(12.dp))
    if (!root) {
        Text("Root permission is not confirmed. Install a supported root backend first.",
            color = Color(0xFFFFC078))
    } else if (modules.isEmpty()) {
        Text("No modules detected, or module listing is unavailable.", color = Muted)
    } else {
        LazyColumn {
            items(modules) { module ->
                InfoRow("Module", module)
            }
        }
    }
    Spacer(Modifier.height(12.dp))
    OutlinedButton(onClick = onRefresh) { Text("Refresh module list") }
    Text("ZIP installation, enable/disable and removal are intentionally gated for the next verified backend integration.",
        color = Muted, fontSize = 11.sp, modifier = Modifier.padding(top = 10.dp))
}

@Composable
fun ToolsScreen(info: RootInfo) {
    Text("Advanced tools", fontSize = 21.sp, fontWeight = FontWeight.Bold)
    Spacer(Modifier.height(12.dp))
    InfoRow("Detected backend", info.backend)
    InfoRow("SELinux mode", info.selinux)
    InfoRow("Kernel", info.kernel)
    Spacer(Modifier.height(12.dp))
    Text("Safety-first build", color = Cyan, fontWeight = FontWeight.Bold)
    Text("This starter build performs read-only detection. It does not flash boot images, change partitions, install arbitrary modules, or modify SELinux. Those actions require device-specific validation and explicit confirmation.",
        color = Muted, fontSize = 12.sp)
}

object RootShell {
    private fun run(command: String): String {
        return try {
            val process = Runtime.getRuntime().exec(arrayOf("sh", "-c", command))
            val output = process.inputStream.bufferedReader().readText()
            process.waitFor()
            output.trim()
        } catch (_: Exception) { "" }
    }

    fun inspect(): Pair<RootInfo, List<String>> {
        val id = run("su -c id")
        val granted = id.contains("uid=0")
        val kernel = run("uname -r").ifBlank { "Unavailable" }
        val selinux = run("getenforce").ifBlank { "Unknown" }
        val backend = when {
            run("su -c 'ksud -V'").isNotBlank() -> "KernelSU / compatible ksud"
            run("su -c 'magisk -v'").isNotBlank() -> "Magisk"
            run("su -c 'apd --version'").isNotBlank() -> "APatch (if supported)"
            granted -> "Generic SU"
            else -> "Not detected"
        }
        val moduleText = if (granted) run("su -c 'ls -1 /data/adb/modules 2>/dev/null'") else ""
        val modules = moduleText.lines().filter { it.isNotBlank() }.take(100)
        val detail = if (granted) "Root shell responded successfully." else
            "No root grant detected. Check that a compatible root manager is installed."
        return RootInfo(granted, backend, kernel, android.os.Build.VERSION.RELEASE ?: "—",
            "${android.os.Build.MANUFACTURER} ${android.os.Build.MODEL}", selinux, detail) to modules
    }
}
